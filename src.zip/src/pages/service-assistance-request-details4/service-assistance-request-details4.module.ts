import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceAssistanceRequestDetails4Page } from './service-assistance-request-details4';

@NgModule({
  declarations: [
    ServiceAssistanceRequestDetails4Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceAssistanceRequestDetails4Page),
  ],
})
export class ServiceAssistanceRequestDetails4PageModule {}
