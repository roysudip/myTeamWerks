import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileDetail3Page } from './profile-detail3';

@NgModule({
  declarations: [
    ProfileDetail3Page,
  ],
  imports: [
    IonicPageModule.forChild(ProfileDetail3Page),
  ],
})
export class ProfileDetail3PageModule {}
