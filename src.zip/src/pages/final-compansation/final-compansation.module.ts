import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalCompansationPage } from './final-compansation';

@NgModule({
  declarations: [
    FinalCompansationPage,
  ],
  imports: [
    IonicPageModule.forChild(FinalCompansationPage),
  ],
})
export class FinalCompansationPageModule {}
