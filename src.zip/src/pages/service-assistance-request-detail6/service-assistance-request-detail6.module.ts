import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceAssistanceRequestDetail6Page } from './service-assistance-request-detail6';

@NgModule({
  declarations: [
    ServiceAssistanceRequestDetail6Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceAssistanceRequestDetail6Page),
  ],
})
export class ServiceAssistanceRequestDetail6PageModule {}
