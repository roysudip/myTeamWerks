import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfileDetail2Page } from './profile-detail2';

@NgModule({
  declarations: [
    ProfileDetail2Page,
  ],
  imports: [
    IonicPageModule.forChild(ProfileDetail2Page),
  ],
})
export class ProfileDetail2PageModule {}
