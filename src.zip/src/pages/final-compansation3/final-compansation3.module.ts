import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalCompansation3Page } from './final-compansation3';

@NgModule({
  declarations: [
    FinalCompansation3Page,
  ],
  imports: [
    IonicPageModule.forChild(FinalCompansation3Page),
  ],
})
export class FinalCompansation3PageModule {}
