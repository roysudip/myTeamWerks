import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequestService2Page } from './request-service2';

@NgModule({
  declarations: [
    RequestService2Page,
  ],
  imports: [
    IonicPageModule.forChild(RequestService2Page),
  ],
})
export class RequestService2PageModule {}
