import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceAssistanceRequestDetails2Page } from './service-assistance-request-details2';

@NgModule({
  declarations: [
    ServiceAssistanceRequestDetails2Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceAssistanceRequestDetails2Page),
  ],
})
export class ServiceAssistanceRequestDetails2PageModule {}
