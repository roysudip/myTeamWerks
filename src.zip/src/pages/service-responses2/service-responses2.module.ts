import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceResponses2Page } from './service-responses2';

@NgModule({
  declarations: [
    ServiceResponses2Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceResponses2Page),
  ],
})
export class ServiceResponses2PageModule {}
