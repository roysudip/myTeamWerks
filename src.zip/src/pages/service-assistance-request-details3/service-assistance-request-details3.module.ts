import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceAssistanceRequestDetails3Page } from './service-assistance-request-details3';

@NgModule({
  declarations: [
    ServiceAssistanceRequestDetails3Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceAssistanceRequestDetails3Page),
  ],
})
export class ServiceAssistanceRequestDetails3PageModule {}
