import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalCompansation2Page } from './final-compansation2';

@NgModule({
  declarations: [
    FinalCompansation2Page,
  ],
  imports: [
    IonicPageModule.forChild(FinalCompansation2Page),
  ],
})
export class FinalCompansation2PageModule {}
