import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistrationStepFivePage } from './registration-step-five';

@NgModule({
  declarations: [
    RegistrationStepFivePage,
  ],
  imports: [
    IonicPageModule.forChild(RegistrationStepFivePage),
  ],
})
export class RegistrationStepFivePageModule {}
