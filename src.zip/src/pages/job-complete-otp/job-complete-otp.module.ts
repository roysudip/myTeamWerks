import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobCompleteOtpPage } from './job-complete-otp';

@NgModule({
  declarations: [
    JobCompleteOtpPage,
  ],
  imports: [
    IonicPageModule.forChild(JobCompleteOtpPage),
  ],
})
export class JobCompleteOtpPageModule {}
