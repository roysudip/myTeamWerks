import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServiceAssistanceRequestDetails5Page } from './service-assistance-request-details5';

@NgModule({
  declarations: [
    ServiceAssistanceRequestDetails5Page,
  ],
  imports: [
    IonicPageModule.forChild(ServiceAssistanceRequestDetails5Page),
  ],
})
export class ServiceAssistanceRequestDetails5PageModule {}
