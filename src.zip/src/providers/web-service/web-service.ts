import { Http, Response,RequestOptions ,Headers} from '@angular/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/toPromise';

@Injectable()
export class WebServiceProvider {
  baseURL = 'http://192.168.1.17:3000';
  constructor(public http: Http) {
  }

    private _errorHandler(error: Response) {
    return Observable.throw(error || "Server Error");
  }

  /*****************User Registration******************* */
  UserRegistration(data){
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    var url = this.baseURL+'/user/createUser';
    return this.http.post(url,data,options)
    .map((response: Response) => response.json())
    .catch(this._errorHandler);
  }
/******************License state list***************** */
getLicencedStateList(){
   let headers = new Headers();
   headers.append('Content-Type', 'application/json');
   let options = new RequestOptions({ headers: headers });
   var url = this.baseURL+'/user/getLicencedStateList';
   return this.http.get(url)
   .map((response: Response) => response.json())
   .catch(this._errorHandler);
}
/******************Designation & Certificate List***************** */
getDesignationsList(){
  let headers = new Headers();
  headers.append('Content-Type', 'application/json');
  let options = new RequestOptions({ headers: headers });
  var url = this.baseURL+'/user/getDesignationsList';
  return this.http.get(url)
  .map((response: Response) => response.json())
  .catch(this._errorHandler);
}

/**************Broker Company Search********************** */
getBrokerCompany(SearchKey){
  let headers = new Headers();
  headers.append('Content-Type', 'application/json');
  let options = new RequestOptions({ headers: headers });
  var url = this.baseURL+'/user/brokerageList?brokerageName='+SearchKey+'';
  console.log(url)
  return this.http.get(url)
  .map((response: Response) => response.json())
  .catch(this._errorHandler);
}

 /*****************User Login******************* */
 UserLogin(data){
  let headers = new Headers();
  headers.append('Content-Type', 'application/json');
  let options = new RequestOptions({ headers: headers });
  var url = this.baseURL+'/user/signIn';
  return this.http.post(url,data,options)
  .map((response: Response) => response.json())
  .catch(this._errorHandler);
}

}
