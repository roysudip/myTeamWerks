import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalCompansation4Page } from './final-compansation4';

@NgModule({
  declarations: [
    FinalCompansation4Page,
  ],
  imports: [
    IonicPageModule.forChild(FinalCompansation4Page),
  ],
})
export class FinalCompansation4PageModule {}
