import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the MyServiceRequestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-my-service-request',
  templateUrl: 'my-service-request.html',
})
export class MyServiceRequestPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyServiceRequestPage');
  }
  ServiceAssistanceRequestDetailsPage(){
    this.navCtrl.push('ServiceAssistanceRequestDetailsPage')
  }

  requestServicePage2(){
    this.navCtrl.push('RequestService2Page');  
  }

  RatingReviewPage(){
    this.navCtrl.push('RatingReviewPage');  
  }
 
  ServiceResponsesPage(){
    this.navCtrl.push('ServiceResponsesPage'); 
  }
  notification(){
    this.navCtrl.push('NotificationPage')
  }

  dashboardPage(){
    this.navCtrl.setRoot('DashboardPage')
  }

  messagePage(){
    this.navCtrl.push('MessagePage')
  }

  serviceAssistanceRequestDetails2Page(){
    this.navCtrl.push('ServiceAssistanceRequestDetails2Page')
  }

  serviceAssistanceRequestDetails3Page(){
    this.navCtrl.push('ServiceAssistanceRequestDetails3Page')
  }

  serviceAssistanceRequestDetails4Page(){
    this.navCtrl.push('ServiceAssistanceRequestDetails4Page')
  }


  serviceResponses2Page(){
    this.navCtrl.push('ServiceResponses2Page')
  }

  profileDetail2Page(){
    this.navCtrl.push('ProfileDetail2Page')
  }
  profileDetail3Page(){
    this.navCtrl.push('ProfileDetail3Page')
  }

  

}
